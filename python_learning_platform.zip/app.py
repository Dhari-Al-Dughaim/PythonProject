import streamlit as st

st.set_page_config(page_title="منصة تعلم بايثون", layout="wide")

st.title("👨‍🏫 منصة تعليم بايثون للمبتدئين")
st.markdown("أهلاً بك في منصتك لتعلم أساسيات لغة Python بشكل تفاعلي وممتع 🎉")

st.info("اختر أحد الدروس أو الأقسام من القائمة الجانبية للبدء بالتعلم.")